#!/usr/bin/env python3
from __future__ import annotations as _annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pathlib import Path

import numpy as np
import pytest
from pydantic_ai import Agent
from pydantic_ai.models.openai import OpenAIChatModel
from pydantic_ai.providers.openai import OpenAIProvider
from pydantic_ai.settings import ModelSettings
from pydantic_evals import Case, Dataset

from deepresearcher2.agents import evaluation_agent
from deepresearcher2.evals.evals import (
    EvalGame,
    EvalPlayer,
    EvalTournament,
    adaptive_uncertainty_strategy,
    random_sampling_strategy,
    round_robin_strategy,
)
from deepresearcher2.logger import logger

MODEL_SETTINGS = ModelSettings(
    temperature=0.0,  # Model needs to be deterministic for VCR recording to work.
    timeout=300,
)


def test_evalplayer() -> None:
    """
    Test the EvalPlayer class.
    """
    logger.info("Testing EvalPlayer() class")

    player = EvalPlayer(
        idx=42,
        item="toasted rice & miso caramel ice cream",
    )
    assert player.idx == 42
    assert player.item == "toasted rice & miso caramel ice cream"


@pytest.mark.vcr()
@pytest.mark.asyncio
async def test_evalgame(ice_cream_players: list[EvalPlayer]) -> None:
    """
    Test the EvalGame class.
    """
    logger.info("Testing EvalGame() class")

    game = EvalGame(criterion="Which of the two ice cream flavours A or B is more creative?")
    assert game.criterion == "Which of the two ice cream flavours A or B is more creative?"

    result = await game.run(
        players=(ice_cream_players[0], ice_cream_players[4]),
        agent=evaluation_agent,
        model_settings=MODEL_SETTINGS,
    )
    logger.debug(f"Game result: {result}")

    assert isinstance(result, tuple)
    assert len(result) == 2
    assert all(isinstance(r, int) for r in result)
    assert result[0] == 4  # Toasted rice & miso caramel ice cream flavour is more creative.


@pytest.mark.vcr()
@pytest.mark.asyncio
async def test_evaltournament(ice_cream_players: list[EvalPlayer], ice_cream_game: EvalGame) -> None:
    """
    Test the EvalTournament class.
    """
    logger.info("Testing EvalTournament() class")

    tournament = EvalTournament(players=ice_cream_players, game=ice_cream_game)

    assert len(tournament.players) == len(ice_cream_players)
    assert tournament.game.criterion == ice_cream_game.criterion

    # Test player retrieval
    player = tournament.get_player_by_idx(1)
    assert player is not None
    assert player.item == ice_cream_players[1].item

    # Test the default strategy
    players_with_scores = await tournament.run(
        agent=evaluation_agent,
        model_settings=MODEL_SETTINGS,
    )
    assert isinstance(players_with_scores, list)
    for player in players_with_scores:
        assert isinstance(player, EvalPlayer)
        assert hasattr(player, "score")
        assert isinstance(player.score, float)
        assert player.score is not None
        logger.debug(f"Player {player.idx} score: {player.score}")

    # Test the random sampling strategy
    players_with_scores = await tournament.run(
        agent=evaluation_agent,
        model_settings=MODEL_SETTINGS,
        strategy=random_sampling_strategy,
        fraction_of_games=0.3,
    )
    assert isinstance(players_with_scores, list)
    for player in players_with_scores:
        assert isinstance(player, EvalPlayer)
        assert hasattr(player, "score")
        assert isinstance(player.score, float)
        assert player.score is not None
        logger.debug(f"Player {player.idx} score: {player.score}")


@pytest.mark.vcr()
@pytest.mark.asyncio
async def test_random_sampling_strategy(ice_cream_players: list[EvalPlayer], ice_cream_game: EvalGame) -> None:
    """
    Test the random sampling tournament strategy.
    """
    logger.info("Testing random_sampling_strategy()")

    players_with_scores = await random_sampling_strategy(
        players=ice_cream_players,
        game=ice_cream_game,
        agent=evaluation_agent,
        model_settings=MODEL_SETTINGS,
        fraction_of_games=0.3,
    )
    assert isinstance(players_with_scores, list)
    for player in players_with_scores:
        assert isinstance(player, EvalPlayer)
        assert hasattr(player, "score")
        assert isinstance(player.score, float)
        assert player.score is not None
        logger.debug(f"Player {player.idx} score: {player.score}")


@pytest.mark.vcr()
@pytest.mark.asyncio
async def test_round_robin_strategy(ice_cream_players: list[EvalPlayer], ice_cream_game: EvalGame) -> None:
    """
    Test the round robin tournament strategy.
    """
    logger.info("Testing round_robin_strategy()")

    players_with_scores = await round_robin_strategy(
        players=ice_cream_players,
        game=ice_cream_game,
        agent=evaluation_agent,
        model_settings=MODEL_SETTINGS,
        number_of_rounds=1,
    )
    assert isinstance(players_with_scores, list)
    for player in players_with_scores:
        assert isinstance(player, EvalPlayer)
        assert hasattr(player, "score")
        assert isinstance(player.score, float)
        assert player.score is not None
        logger.debug(f"Player {player.idx} score: {player.score}")


@pytest.mark.vcr()
@pytest.mark.asyncio
async def test_adaptive_uncertainty_strategy(ice_cream_players: list[EvalPlayer], ice_cream_game: EvalGame) -> None:
    """
    Test the adaptive uncertainty tournament strategy.
    """
    logger.info("Testing adaptive_uncertainty_strategy()")

    players_with_scores = await adaptive_uncertainty_strategy(
        players=ice_cream_players,
        game=ice_cream_game,
        agent=evaluation_agent,
        model_settings=MODEL_SETTINGS,
        max_standard_deviation=1.0,
        alpha=0.01,
    )
    assert isinstance(players_with_scores, list)
    for player in players_with_scores:
        assert isinstance(player, EvalPlayer)
        assert hasattr(player, "score")
        assert isinstance(player.score, float)
        assert player.score is not None
        logger.debug(f"Player {player.idx} score: {player.score}")


@pytest.mark.vcr()
@pytest.mark.asyncio
async def test_evaltournament_usecase(tmp_path: Path) -> None:
    """
    Use case for EvalTournament, EvalGame and EvalPlayer classes.

    The code demonstrates how the evaluation framework can be used in practice. It is not intended as test for individual components.
    In this use case, we are provided with a list of topics. The objective is to generate creative web search queries for these topics.
    We have a basline implementation in the `main` branch and a novel implementation in some `feature` branch. In this simple example,
    the implementations differ merely in the prompt: `prompt_baseline` vs. `prompt_novel`. We want to check whether the novel implementation
    does indeed generate more creative queries.

    The use case proceeds in three steps:
    (1) We generate an evaluation `Dataset` containing the topics.
    (2) We run the baseline implementation and store the generated queries in the dataset. This code could be run as part of the
        CI/CD pipeline whenever the `main` branch changes.
    (3) We run the novel implementation, score both baseline and novel queries in one go using a Bradley-Terry tournament,
        and check whether the scores have improved.
    """

    # Path to store the evaluation dataset
    path_out = tmp_path / "dataset.json"

    # Agent for generating search queries using a local Ollama server
    query_agent = Agent(
        model=OpenAIChatModel(
            model_name="qwen2.5:72b",
            provider=OpenAIProvider(base_url="http://localhost:11434/v1"),
        ),
        output_type=str,
        system_prompt="Please generate a concise web search query for the given research topic. Reply with ONLY the query string. Do NOT use quotes.",
        retries=5,
        instrument=True,
    )

    logger.info("Use case for EvalTournament, EvalGame and EvalPlayer classes.")

    # (1) Generate Cases and serialise them

    topics = [
        "pangolin trafficking networks",
        "molecular gastronomy",
        "dark kitchen economics",
        "kintsugi philosophy",
        "nano-medicine delivery systems",
        "Streisand effect dynamics",
        "social cooling phenomenon",
        "Anne Brorhilke",
        "bioconcrete self-healing",
        "bacteriophage therapy revival",
    ]

    cases: list[Case[dict[str, str], type[None], Any]] = []
    for idx, topic in enumerate(topics):
        logger.info(f"Case {idx + 1} / {len(topics)} with topic: {topic}")
        case = Case(
            name=f"case_{idx:03d}",
            inputs={"topic": topic},
        )
        cases.append(case)
    dataset: Dataset[dict[str, str], type[None], Any] = Dataset[dict[str, str], type[None], Any](cases=cases)
    dataset.to_file(path_out)

    # (2) Generate base line model outputs

    dataset = Dataset[dict[str, str], type[None], Any].from_file(path_out)
    cases_new: list[Case[dict[str, str], type[None], Any]] = []
    for case in dataset.cases:
        logger.info(f"Case {case.name} with topic: {case.inputs['topic']}")

        prompt_baseline = f"Please generate a query for the research topic: <TOPIC>{case.inputs['topic']}</TOPIC>"
        async with query_agent:
            result = await query_agent.run(
                user_prompt=prompt_baseline,
                model_settings=MODEL_SETTINGS,
            )

        logger.debug(f"Generated query: {result.output}")
        case_new = Case(
            name=case.name,
            inputs={"topic": case.inputs["topic"], "query": result.output},
        )
        cases_new.append(case_new)
    dataset_new: Dataset[dict[str, str], type[None], Any] = Dataset[dict[str, str], type[None], Any](cases=cases_new)
    dataset_new.to_file(path_out)

    # (3) Generate novel model outputs and score them

    dataset = Dataset[dict[str, str], type[None], Any].from_file(path_out)
    players: list[EvalPlayer] = []
    for idx, case in enumerate(dataset.cases):
        logger.info(f"Case {case.name} with topic: {case.inputs['topic']}")

        prompt_novel = (
            f"Please generate a very creative search query for the research topic: <TOPIC>{case.inputs['topic']}</TOPIC>\n"
            "The query should show genuine originality and interest in the topic. AVOID any generic or formulaic phrases."
        )
        async with query_agent:
            result = await query_agent.run(
                user_prompt=prompt_novel,
                model_settings=MODEL_SETTINGS,  # Ideally, we want to use non-zero temperature here. But for VCR testing we need determinism.
            )

        logger.debug(f"Generated query: {result.output}")

        player_baseline = EvalPlayer(idx=idx, item=case.inputs["query"])
        player_novel = EvalPlayer(idx=idx + len(dataset.cases), item=result.output)
        players.append(player_baseline)
        players.append(player_novel)

    # Run the Bradley-Terry tournament to score both baseline and novel queries
    game = EvalGame(criterion="Which of the two search queries shows more genuine curiosity and creativity, and is less formulaic?")
    tournament = EvalTournament(players=players, game=game)
    players_scored = await tournament.run(
        agent=evaluation_agent,
        model_settings=MODEL_SETTINGS,
    )

    # Players sorted by score
    players_sorted = sorted(players_scored, key=lambda p: p.score if p.score is not None else float("-inf"))
    for player in players_sorted:
        logger.debug(f"Player {player.idx:4d}   score: {player.score:7.4f}   item: {player.item}")

    # Average score for both baseline and novel queries
    scores_baseline = [tournament.get_player_by_idx(idx=i).score or 0.0 for i in range(len(dataset.cases))]
    scores_novel = [tournament.get_player_by_idx(idx=i + len(dataset.cases)).score or 0.0 for i in range(len(dataset.cases))]
    logger.debug(f"Average score for baseline queries: {np.mean(scores_baseline):0.4f}")
    logger.debug(f"Average score for novel queries:    {np.mean(scores_novel):0.4f}")
    # Not every novel query will have scored higher than the baseline case.But on average the novel queries should have improved scores.
    assert np.mean(scores_novel) > np.mean(scores_baseline)
