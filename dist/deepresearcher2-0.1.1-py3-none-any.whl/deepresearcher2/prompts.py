#!/usr/bin/env python3

instructions = """
Your goal is to research and provide a comprehensive overview of the topic.
Please include relevant data, insights, and references in your response.
"""
