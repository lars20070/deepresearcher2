# import asyncio

# import logfire
# from pydantic_ai import Agent
# from pydantic_ai.models.openai import OpenAIModel
# from pydantic_ai.providers.openai import OpenAIProvider
# from pydantic_ai.settings import ModelSettings

# from deepresearcher2.logger import logger


# async def main() -> None:
#     logfire.configure()
#     logfire.instrument_httpx(capture_all=True)
#     logfire.instrument_pydantic_ai()

#     logger.info("Testing PydanticAI Agent() class with a local Ollama model with different temperatures.")

#     model = "llama3.3"
#     # model = "qwen3:8b"
#     ollama_model = OpenAIModel(
#         model_name=model,
#         provider=OpenAIProvider(
#             base_url="http://localhost:11434/v1",
#         ),
#     )

#     agent = Agent(ollama_model)

#     prompt = "Describe a new ice cream flavour? Answer in a single short sentence."
#     logger.debug(f"Prompt:\n{prompt}")

#     model_settings_1 = ModelSettings(temperature=0.01)
#     model_settings_2 = ModelSettings(temperature=0.99)

#     result_1 = await agent.run(prompt, model_settings=model_settings_1)
#     result_2 = await agent.run(prompt, model_settings=model_settings_2)

#     logger.debug(f"Result from agent (low temperature):\n{result_1.output}")
#     logger.debug(f"Result from agent (high temperature):\n{result_2.output}")


# if __name__ == "__main__":
#     asyncio.run(main())


from pydantic_ai import Agent
from pydantic_ai.models.openai import OpenAIModel
from pydantic_ai.providers.openai import OpenAIProvider
from pydantic_ai.settings import ModelSettings

ollama_model = OpenAIModel(model_name="llama3.3", provider=OpenAIProvider(base_url="http://localhost:11434/v1"))
agent = Agent(ollama_model)

prompt = "Describe a new ice cream flavour? Answer in a single short sentence."
for temp in [0, 2]:
    print(temp)
    for _ in range(5):
        print(agent.run_sync(prompt, model_settings=ModelSettings(temperature=temp)))
