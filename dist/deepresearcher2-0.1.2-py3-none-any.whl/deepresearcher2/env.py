#!/usr/bin/env python3

from dotenv import load_dotenv

# Load environment variables once
load_dotenv()
