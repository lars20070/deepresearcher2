#!/usr/bin/env python3
from __future__ import annotations as _annotations

import asyncio
from dataclasses import dataclass

from dotenv import load_dotenv
from pydantic_ai import format_as_xml
from pydantic_ai.settings import ModelSettings
from pydantic_graph import BaseNode, End, Graph, GraphRunContext

from .agents import FINAL_SUMMARY_AGENT, QUERY_AGENT, REFLECTION_AGENT, SUMMARY_AGENT
from .config import SearchEngine, config
from .logger import logger
from .models import DeepState, Reference, Reflection, WebSearchSummary
from .prompts import QUERY_INSTRUCTIONS_WITH_REFLECTION, QUERY_INSTRUCTIONS_WITHOUT_REFLECTION
from .utils import (
    brave_search,
    duckduckgo_search,
    export_report,
    perplexity_search,
    remove_reasoning_tags,
    searxng_search,
    serper_search,
    tavily_search,
)

load_dotenv()


# Nodes
@dataclass
class WebSearch(BaseNode[DeepState]):
    """
    Web Search node.
    """

    async def run(self, ctx: GraphRunContext[DeepState]) -> SummarizeSearchResults:
        logger.debug(f"Running Web Search with count number {ctx.state.count}.")

        topic = ctx.state.topic

        @QUERY_AGENT.system_prompt
        def add_reflection() -> str:  # pyright: ignore[reportUnusedFunction]
            """
            Add reflection from the previous loop to the system prompt.
            """
            if ctx.state.reflection:
                xml = format_as_xml(ctx.state.reflection, root_tag="reflection")
                return QUERY_INSTRUCTIONS_WITH_REFLECTION + f"Reflection on existing knowledge:\n{xml}\n" + "Provide your response in JSON format."
            else:
                return QUERY_INSTRUCTIONS_WITHOUT_REFLECTION

        # Generate the query
        async with QUERY_AGENT:
            prompt = f"Please generate a web search query for the following topic: <TOPIC>{topic}</TOPIC>"
            result = await QUERY_AGENT.run(
                user_prompt=prompt,
                model_settings=ModelSettings(
                    temperature=config.temperature_query,
                    timeout=config.model_timeout,
                ),
            )
            ctx.state.search_query = result.output
            # Exclude PDF files from search results. We cannot fetch the content anyway.
            ctx.state.search_query.query += " -filetype:pdf"
            logger.debug(f"Web search query:\n{ctx.state.search_query.model_dump_json(indent=2)}")

        # Run the search
        search_params = {
            "query": ctx.state.search_query.query,
            "max_results": config.max_web_search_results,
            "max_content_length": 12000,
        }
        if config.search_engine == SearchEngine.duckduckgo:
            ctx.state.search_results = duckduckgo_search(**search_params)  # pyright: ignore[reportArgumentType]
        elif config.search_engine == SearchEngine.tavily:
            ctx.state.search_results = tavily_search(**search_params)  # pyright: ignore[reportArgumentType]
        elif config.search_engine == SearchEngine.perplexity:
            ctx.state.search_results = perplexity_search(ctx.state.search_query.query)
        elif config.search_engine == SearchEngine.brave:
            ctx.state.search_results = brave_search(**search_params)  # pyright: ignore[reportArgumentType]
        elif config.search_engine == SearchEngine.serper:
            ctx.state.search_results = serper_search(**search_params)  # pyright: ignore[reportArgumentType]
        elif config.search_engine == SearchEngine.searxng:
            ctx.state.search_results = searxng_search(**search_params)  # pyright: ignore[reportArgumentType]
        else:
            message = f"Unsupported search engine: {config.search_engine}"
            logger.error(message)
            raise ValueError(message)

        # logger.debug(f"Web search results:\n{format_as_xml(ctx.state.search_results, root_tag='search_results')}")

        return SummarizeSearchResults()


@dataclass
class SummarizeSearchResults(BaseNode[DeepState]):
    """
    Summarize Search Results node.
    """

    async def run(self, ctx: GraphRunContext[DeepState]) -> ReflectOnSearch:
        logger.debug(f"Running Summarize Search Results with count number {ctx.state.count}.")

        @SUMMARY_AGENT.system_prompt
        def add_web_search_results() -> str:  # pyright: ignore[reportUnusedFunction]
            """
            Add web search results to the system prompt.
            """
            xml = format_as_xml(ctx.state.search_results, root_tag="search_results")
            return f"List of web search results:\n{xml}"

        # Generate the summary
        async with SUMMARY_AGENT:
            result = await SUMMARY_AGENT.run(
                user_prompt=f"Please summarize the provided web search results for the topic <TOPIC>{ctx.state.topic}</TOPIC>.",
                model_settings=ModelSettings(
                    temperature=config.temperature_summary,
                    timeout=config.model_timeout,
                ),
            )
            result.output = remove_reasoning_tags(result.output)
            # logger.debug(f"Web search summary:\n{result.output}")

            # Transfer search result references to the summary
            references: list[Reference] = []
            for ref in ctx.state.search_results or []:
                if ref.title and ref.url:
                    references.append(Reference(title=ref.title, url=ref.url))

            aspect = ctx.state.search_query.aspect if ctx.state.search_query is not None else "General"
            summary = WebSearchSummary(
                summary=result.output,  # Summary from the agent
                aspect=aspect,  # Aspect from the search query
                references=references,  # References from the search results
            )
            # logger.debug(f"Summary result:\n{format_as_xml(summary, root_tag='single_search_summary')}")

            # Append the summary to the list of all search summaries
            ctx.state.search_summaries = ctx.state.search_summaries or []
            ctx.state.search_summaries.append(summary)

        return ReflectOnSearch()


@dataclass
class ReflectOnSearch(BaseNode[DeepState]):
    """
    Reflect on Search node.
    """

    async def run(self, ctx: GraphRunContext[DeepState]) -> WebSearch | FinalizeSummary:
        logger.debug(f"Running Reflect on Search with count number {ctx.state.count}.")

        # Flow control
        # Should we ponder on the next web search or compile the final report?
        if ctx.state.count < config.max_research_loops:
            ctx.state.count += 1

            # xml = format_as_xml(ctx.state.search_summaries, root_tag="search_summaries")
            # logger.debug(f"Search summaries:\n{xml}")

            @REFLECTION_AGENT.system_prompt
            def add_search_summaries() -> str:  # pyright: ignore[reportUnusedFunction]
                """
                Add search summaries to the system prompt.
                """
                xml = format_as_xml(ctx.state.search_summaries, root_tag="search_summaries")
                return f"List of search summaries:\n{xml}"

            # Reflect on the summaries so far
            async with REFLECTION_AGENT:
                reflection = await REFLECTION_AGENT.run(
                    user_prompt=f"Please reflect on the provided web search summaries for the topic <TOPIC>{ctx.state.topic}</TOPIC>.",
                    model_settings=ModelSettings(
                        temperature=config.temperature_reflection,
                        timeout=config.model_timeout,
                    ),
                )
                logger.debug(f"Reflection knowledge gaps:\n{reflection.output.knowledge_gaps}")
                logger.debug(f"Reflection covered topics:\n{reflection.output.covered_topics}")

                ctx.state.reflection = Reflection(
                    knowledge_gaps=reflection.output.knowledge_gaps,
                    covered_topics=reflection.output.covered_topics,
                )

            return WebSearch()
        else:
            return FinalizeSummary()


@dataclass
class FinalizeSummary(BaseNode[DeepState]):
    """
    Finalize Summary node.
    """

    async def run(self, ctx: GraphRunContext[DeepState]) -> End:  # pyright: ignore[reportIncompatibleMethodOverride]
        logger.debug("Running Finalize Summary.")

        topic = ctx.state.topic

        xml = format_as_xml(ctx.state.search_summaries, root_tag="search_summaries")
        logger.debug(f"Search summaries:\n{xml}")

        @FINAL_SUMMARY_AGENT.system_prompt
        def add_search_summaries() -> str:  # pyright: ignore[reportUnusedFunction]
            """
            Add search summaries to the system prompt.
            """
            xml = format_as_xml(ctx.state.search_summaries, root_tag="search_summaries")
            return f"List of search summaries:\n{xml}"

        # Finalize the summary of the entire report
        async with FINAL_SUMMARY_AGENT:
            final_summary = await FINAL_SUMMARY_AGENT.run(
                user_prompt=f"Please summarize all web search summaries for the topic <TOPIC>{ctx.state.topic}</TOPIC>.",
                model_settings=ModelSettings(
                    temperature=config.temperature_final_summary,
                    timeout=config.model_timeout,
                ),
            )
            logger.debug(f"Final summary:\n{final_summary.output.summary}")

        # Compile the final report
        report = f"# {topic}\n\n"
        report += f"{final_summary.output.summary}\n\n"  # Overall summary
        for summary in ctx.state.search_summaries or []:  # Summaries of individual searches
            report += f"\n## {summary.aspect}\n\n"
            report += f"{summary.summary}\n\n"
            report += "### References\n"
            for ref in summary.references or []:
                report += f"- {ref.title} [{ref.url}]({ref.url})\n"
            report += "\n"

        # Export the report
        export_report(report=report, topic=topic, output_dir=config.reports_folder)

        return End(None)


# Workflow
async def deepresearch() -> None:
    """
    Graph use
    """
    logger.info("Starting deep research workflow.")

    # Define the agent graph
    graph = Graph(nodes=[WebSearch, SummarizeSearchResults, ReflectOnSearch, FinalizeSummary])

    # Run the agent graph
    state = DeepState(topic=config.topic, count=1)
    result = await graph.run(WebSearch(), state=state)
    logger.debug(f"Result: {result.output}")

    # Mermaid code
    # mermaid_code = graph.mermaid_code(start_node=WebSearch())
    # logger.debug(f"Mermaid graph:\n{mermaid_code}")


def main() -> None:
    """
    Main function containing the deep research workflow.
    """

    logger.info("Starting deep research.")
    asyncio.run(deepresearch())


if __name__ == "__main__":
    main()
